require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/scripts/interp.lua"

function init()
  self.edges = getCollisionEdges()
	
  self.landingCheck = false
  self.vectorCheck = false
  self.isBoosting = false
  self.boostDelay = 0
  self.soundTimer = 0
  self.displayTimer = 0
  self.stabilizeTimer = 0
	
  self.hoverHeight = 0
  self.activeTimer = 0
  self.maxHoverHeight = config.getParameter("maxHoverHeight")
  self.hoverSpeedMultiplier = config.getParameter("hoverSpeedMultiplier")
  self.hoverAcceleration = config.getParameter("hoverAcceleration")
  self.bobInterval = config.getParameter("bobInterval")
  self.bobAmount = config.getParameter("bobAmount")
  self.fallSpeedLimit = -40
	
  self.movementParameters = config.getParameter("movementParameters", {})
  self.movementParametersOutOfFuelGround = config.getParameter("movementParametersOutOfFuelGround", {})
  self.movementParametersOutOfFuelFalling = config.getParameter("movementParametersOutOfFuelFalling", {})

  animator.setAnimationState("resourcedisplay", "invisible")
  getResources()
end

function getResources()
  resource = "energy"
  resourceValue = status.resourcePercentage(resource)
end

function loadSound()
  if self.soundTimer == 0 then
    playSound()
  end
end

function playSound()
  if self.soundTimer == 0 then
	animator.playSound("fly", 0)
    self.soundTimer = 2
  end
end

function update(dt)
  --Utilities, deg = util.rad2deg(rad) util.toDegrees() or util.toRadians()
  
  rotationAngle = util.toDegrees(mcontroller.rotation()) --Do not use as part of set rotation function. Used to override Direction angle.
  directionAngle = vec2.angle(mcontroller.velocity()) - util.toRadians(90) --Use to set rotation Angle.
  defaultAngle = util.toRadians(360) * mcontroller.facingDirection()
  
  self.boostDelay = math.max(0, self.boostDelay + dt)
  self.soundTimer = math.max(self.soundTimer - dt, 0)
  self.displayTimer = math.max(self.displayTimer - dt, 0)
  self.stabilizeTimer = math.max(self.stabilizeTimer - dt)
	
  self.activeTimer = self.activeTimer + dt
  setHoverHeight(self.activeTimer, dt)
	
  groundDistance = findGroundDistance()
  position = mcontroller.position()
  actualXVelocity = mcontroller.xVelocity()
  actualYVelocity = mcontroller.yVelocity()
	
  --Movement parameters; uodate only when in gravity.
  if world.gravity(position) > 0.1 then
    visualEffects(dt)
	resourceLockedMovement()
	flyVector()
    flyAtmosphere()
    slowFall()
  end
	
  --flySpace() -- keep this updating at all times.
  getResources()
end

function visualEffects(dt)
  local edges = getCollisionEdges()
  local boundBox = mcontroller.boundBox()

  --Particles at feet
  boundBox[2] = edges.bottom
  boundBox[4] = edges.bottom
  
  -- Exhaust effects disabled and utilized in fuel version of jetpack. makes more sense.
  if not mcontroller.groundMovement() then
	if mcontroller.facingDirection() == 1 then 
	  --animator.setParticleEmitterActive("exhaustright", true)
	  --animator.setParticleEmitterActive("exhaustleft", false)
	  --loadSound()
    elseif mcontroller.facingDirection() == -1 then
	  --animator.setParticleEmitterActive("exhaustright", false)
	  --animator.setParticleEmitterActive("exhaustleft", true)
	  --loadSound()
	end
  elseif mcontroller.groundMovement() then
	--animator.resetTransformationGroup("exhaust")
	--animator.stopAllSounds("fly")
	--animator.setParticleEmitterActive("exhaustright", false)
    --animator.setParticleEmitterActive("exhaustleft", false)
  end
  
  if self.displayTimer < 0.5 then
    if resourceValue == 1.0 then animator.setAnimationState("resourcedisplay", "idle")
      elseif resourceValue >= 0.9 and resourceValue ~= 1.0 then animator.setAnimationState("resourcedisplay", "100")
      elseif resourceValue >= 0.8 and resourceValue < 0.9 then animator.setAnimationState("resourcedisplay", "90")
      elseif resourceValue >= 0.7 and resourceValue < 0.8 then animator.setAnimationState("resourcedisplay", "80")
      elseif resourceValue >= 0.6 and resourceValue < 0.7 then animator.setAnimationState("resourcedisplay", "70")
      elseif resourceValue >= 0.5 and resourceValue < 0.6 then animator.setAnimationState("resourcedisplay", "60")
      elseif resourceValue >= 0.4 and resourceValue < 0.5 then animator.setAnimationState("resourcedisplay", "50")
      elseif resourceValue >= 0.3 and resourceValue < 0.4 then animator.setAnimationState("resourcedisplay", "40")
      elseif resourceValue >= 0.2 and resourceValue < 0.3 then animator.setAnimationState("resourcedisplay", "30")
      elseif resourceValue >= 0.1 and resourceValue < 0.2 then animator.setAnimationState("resourcedisplay", "20")
      elseif resourceValue ~= 0.0 and resourceValue < 0.1 then animator.setAnimationState("resourcedisplay", "10")
      elseif resourceValue == 0.0 then animator.setAnimationState("resourcedisplay", "0")
      else animator.setAnimationState("resourcedisplay", "invisible")
    end
  end
  if self.displayTimer == 0.0 and resourceValue <= 0.35 and resourceValue ~= 0 then
	animator.setAnimationState("resourcedisplay", "0")
	self.displayTimer = 1
  end
end

function setHoverHeight(time, dt)
  --Sin makes you bob
  local sinTime = math.sin(time / self.bobInterval * 6.28)
  self.hoverHeight = self.maxHoverHeight + sinTime * self.bobAmount
end

function getCollisionEdges()
  local collisionPoly = mcontroller.collisionPoly()

  local edges = {
    left = 0,
    top = 0,
    right = 0,
    bottom = 0
  }

  for _,point in ipairs(collisionPoly) do
    if point[1] < edges.left then edges.left = point[1] end
    if point[2] > edges.top then edges.top = point[2] end
    if point[1] > edges.right then edges.right = point[1] end
    if point[2] < edges.bottom then edges.bottom = point[2] end
  end

  return edges
end

function resourceLockedMovement()
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  or status.resourceLocked(resource)
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement() then
	--animator.setParticleEmitterActive("exhaustright", false) -- we're out of fuel. Switch the engines off
    --animator.setParticleEmitterActive("exhaustleft", false)
    if not self.landingCheck then 
	  status.setResource(resource, 0)
	  mcontroller.controlModifiers({ jumpingSuppressed = true })
	  mcontroller.controlParameters(self.movementParametersOutOfFuelFalling)
	end
  elseif resourceValue == 0 and mcontroller.liquidMovement()
	  or resourceValue == 0 and mcontroller.groundMovement()
	  or status.resourceLocked(resource) and mcontroller.liquidMovement()
	  or status.resourceLocked(resource) and mcontroller.groundMovement() then
	mcontroller.controlParameters(self.movementParametersOutOfFuelGround)
	mcontroller.controlModifiers({ jumpingSuppressed = false })
	self.landingCheck = true
	animator.stopAllSounds("fly")
  elseif resourceValue ~= 0 or not status.resourceLocked(resource) then
    self.landingCheck = false
	mcontroller.controlParameters(self.movementParameters)
  end
end

function flyAtmosphere()
  groundDistance = findGroundDistance()
  local xVelocity = mcontroller.xVelocity() * mcontroller.facingDirection()
  local yVelocity = mcontroller.yVelocity()
	
  if mcontroller.jumping() and resourceValue ~= 0 then
    mcontroller.controlParameters({ gravityMultiplier = 0.175 })
	mcontroller.controlModifiers({ speedModifier = 3.5 })
	status.overConsumeResource(resource, 0.1)
  elseif mcontroller.falling() then
    status.overConsumeResource(resource, 0.075)
	  if resourceValue ~= 0 then
	    mcontroller.controlParameters({ gravityMultiplier = 0.7 })
	    mcontroller.controlModifiers({ speedModifier = 3.5 })
	  end
  elseif not mcontroller.groundMovement() and resourceValue ~= 0 then
	if xVelocity > 40 and mcontroller.facingDirection() == 1 and groundDistance > 20
	or xVelocity > 40 and mcontroller.facingDirection() == -1 and groundDistance > 20 then
      mcontroller.controlApproachYVelocity(0, 100)
	  mcontroller.controlParameters({ gravityMultiplier = 0.01 })
	  status.overConsumeResource(resource, 0.125)
    else
	  mcontroller.controlParameters({ gravityMultiplier = 0.7 })
	  status.overConsumeResource(resource, 0.075)
    end
	mcontroller.controlModifiers({speedModifier = 3.75})
	midAirHover()
  end
end

function flyVector()
-- to do, make rotation for ground approach based on facing direction mcontroller.jumping() or
--local angleAdjust = self.stabilizeTimer * actualYVelocity * mcontroller.facingDirection()
	
  groundDistance = findGroundDistance()
  local sensitivity = 10 * mcontroller.facingDirection()
  local senseGroundAngle = ((mcontroller.xVelocity() / sensitivity) * mcontroller.yVelocity()) / (1 + groundDistance)
  local stabilizeTimer = (self.stabilizeTimer / 2)
	
  if not itemPrimary or not itemAlt then
	
  if not mcontroller.groundMovement() and groundDistance > 20 then
    mcontroller.setRotation(directionAngle)
	self.vectorCheck = true
	self.stabilizeTimer = 2.0
  elseif not mcontroller.groundMovement()
    and groundDistance <= 20
	and groundDistance > 2
	and self.vectorCheck
	and self.stabilizeTimer ~= 0 then
	  if actualXVelocity >= -25 and actualXVelocity <= 25 then
		if mcontroller.facingDirection() == 1 then
	      mcontroller.setRotation(util.toRadians(rotationAngle - senseGroundAngle) * stabilizeTimer)
	    elseif mcontroller.facingDirection() == -1 then
		  mcontroller.setRotation(util.toRadians(rotationAngle + senseGroundAngle) * stabilizeTimer)
	    end
	  else
	    mcontroller.setRotation(directionAngle)
	  end
	  if actualYVelocity > 0 then
	    actualYVelocity = actualYVelocity
	  else
		mcontroller.controlApproachYVelocity(-1.5, 80)
	  end
  elseif mcontroller.groundMovement()
	or groundDistance <= 2
	or self.stabilizeTimer == 0 then
	  mcontroller.setRotation(defaultAngle)
	  self.vectorCheck = false 
  end
		
  end
  
end

function midAirHover()
  if actualXVelocity >= -17
  and actualXVelocity <= 17
  and actualYVelocity >= -15
  and actualYVelocity <= 5
  and not mcontroller.groundMovement()
  and not status.resourceLocked(resource)
  or actualXVelocity >= -17
  and actualXVelocity <= 17
  and actualYVelocity >= -15
  and actualYVelocity <= 5
  and not mcontroller.groundMovement()
  and resourceValue ~= 0 then
	
	if mcontroller.facingDirection() == 1 then
	  mcontroller.setRotation(defaultAngle + ((actualXVelocity * -1) / 13))
	elseif mcontroller.facingDirection() == -1 then
	  mcontroller.setRotation(defaultAngle - ((actualXVelocity * 1) / 13))
    end
	
    mcontroller.controlApproachYVelocity(0, 20)
	mcontroller.controlParameters({
	  gravityMultiplier = 0.05,
	  airFriction = 2.5
	})
	mcontroller.controlModifiers({speedModifier = 0.7})
    status.overConsumeResource(resource, 0.02)
  end
end

function slowFall()
  groundDistance = findGroundDistance()
	
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and not self.landingCheck
  and self.fallSpeedLimit > mcontroller.yVelocity()
  or status.resourceLocked(resource)	
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and not self.landingCheck
  and mcontroller.yVelocity() > self.fallSpeedLimit then
    mcontroller.controlApproachYVelocity(self.fallSpeedLimit, 350)
  elseif self.fallSpeedLimit > mcontroller.yVelocity()
  and groundDistance <= 60
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement() then
    mcontroller.controlApproachYVelocity(-10 , 500)
  end
end

function flySpace()
  
  if mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
    if not self.isBoosting and self.boostDelay > 0.01 then
	  self.isBoosting = true
	elseif self.isBoosting and self.boostDelay > 0.02 then
	  self.isBoosting = false
	  self.boostDelay = 0
	end
	
    if mcontroller.yVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() + 0.4})
	elseif mcontroller.yVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.yVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() - 0.4})
	elseif mcontroller.yVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
    if mcontroller.xVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() + 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.xVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() - 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	mcontroller.setRotation(defaultAngle)
	--reference code
	--if mcontroller.xVelocity() > 0.05 and self.isBoosting then
    --  mcontroller.setVelocity({mcontroller.xVelocity() + 10, mcontroller.yVelocity()})
	--end
	
  elseif not mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
    mcontroller.setVelocity({0,0})
  end
end

function getClosestBlockYDistance(lineStart, lineEnd, ignorePlatforms)
  local yDistance = false
  local collisionSet = {"Null", "Block", "Dynamic", "Platform"}
  if ignorePlatforms then
    collisionSet = {"Null", "Block", "Dynamic", "Slippery"}
  end
  local blocks = world.collisionBlocksAlongLine(lineStart, lineEnd, collisionSet)
  if #blocks > 0 then
    yDistance = lineStart[2] - (blocks[1][2] + 1)
  end

  -- sb.logInfo("Block: %s Distance: %s", blocks[1], yDistance)

  return yDistance
end

function findGroundDistance()
  local position = mcontroller.position()
  --These are so rays don't start inside blocks
  local sideEdgeOffset = 0.1
  local bottomStartOffset = 0.5
  local centerBottomStartOffset = 0.1

  --Left ray
  local lineStart = {
    position[1] + self.edges.left + sideEdgeOffset,
    position[2] + self.edges.bottom + bottomStartOffset
  }
  local lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - bottomStartOffset
  }

  local leftGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  leftGroundDistance = leftGroundDistance - bottomStartOffset

  --Right ray
  lineStart = {
    position[1] + self.edges.right - sideEdgeOffset,
    position[2] + self.edges.bottom + bottomStartOffset
  }
  local lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - bottomStartOffset
  }

  local rightGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  rightGroundDistance = rightGroundDistance - bottomStartOffset

  --Center ray
  lineStart = {
    position[1],
    position[2] + self.edges.bottom + centerBottomStartOffset
  }
  lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - centerBottomStartOffset
  }

  local centerGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  centerGroundDistance = centerGroundDistance - centerBottomStartOffset

  --Get the closest one
  local groundDistance = math.min(leftGroundDistance, rightGroundDistance)
  groundDistance = math.min(groundDistance, centerGroundDistance)

  return groundDistance
end

function uninit()
  effect.expire()
  mcontroller.setRotation(0)
end


