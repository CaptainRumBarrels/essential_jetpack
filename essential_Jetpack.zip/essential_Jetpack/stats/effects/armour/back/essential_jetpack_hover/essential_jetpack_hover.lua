function init()
  self.edges = getCollisionEdges()
  
  self.jetpacksound = false
  self.landingCheck = false
  self.isBoosting = false
  self.boostDelay = 0
  self.hoverHeight = 10
  self.shutdownTimer = 0
  self.activeTimer = 0
  self.soundTimer = 0
  self.displayTimer = 0
	
  self.bobInterval = config.getParameter("bobInterval")
  self.bobAmount = config.getParameter("bobAmount")
  self.fallSpeedLimit = config.getParameter("fallSpeedLimit")
  self.maxHoverHeight = config.getParameter("maxHoverHeight")
  self.hoverSpeedMultiplier = config.getParameter("hoverSpeedMultiplier")
  self.hoverAcceleration = config.getParameter("hoverAcceleration")	
  self.movementParametersGround = config.getParameter("movementParametersGround", {})
  self.movementParametersHover = config.getParameter("movementParametersHover", {})
  self.movementParametersFlight = config.getParameter("movementParametersAirjump", {})
	
  getResources()
end

function getResources()
  resource = "energy"
  resourceValue = status.resourcePercentage(resource)
end

function loadSound()
  if self.soundTimer == 0 then
    playSound()
  end
end

function playSound()
  if self.soundTimer == 0 then
	animator.playSound("fly", 0)
    self.soundTimer = 2
  end
end

function visualEffects(dt)
  local edges = getCollisionEdges()
  local boundBox = mcontroller.boundBox()

  --Particles at feet
  boundBox[2] = edges.bottom
  boundBox[4] = edges.bottom
	
  if not mcontroller.groundMovement() then
	if mcontroller.facingDirection() == 1 then 
	  --animator.setParticleEmitterActive("exhaustright", true)
	  --animator.setParticleEmitterActive("exhaustleft", false)
	  --loadSound()
    elseif mcontroller.facingDirection() == -1 then
	  --animator.setParticleEmitterActive("exhaustright", false)
	  --animator.setParticleEmitterActive("exhaustleft", true)
	  --loadSound()
	end
  elseif mcontroller.groundMovement() then
	--animator.resetTransformationGroup("exhaust")
	animator.stopAllSounds("fly")
	--animator.setParticleEmitterActive("exhaustright", false)
    --animator.setParticleEmitterActive("exhaustleft", false)
  end
	
  if self.displayTimer < 0.5 then
    if resourceValue == 1.0 then animator.setAnimationState("resourcedisplay", "idle")
      elseif resourceValue >= 0.9 and resourceValue ~= 1.0 then animator.setAnimationState("resourcedisplay", "100")
      elseif resourceValue >= 0.8 and resourceValue < 0.9 then animator.setAnimationState("resourcedisplay", "90")
      elseif resourceValue >= 0.7 and resourceValue < 0.8 then animator.setAnimationState("resourcedisplay", "80")
      elseif resourceValue >= 0.6 and resourceValue < 0.7 then animator.setAnimationState("resourcedisplay", "70")
      elseif resourceValue >= 0.5 and resourceValue < 0.6 then animator.setAnimationState("resourcedisplay", "60")
      elseif resourceValue >= 0.4 and resourceValue < 0.5 then animator.setAnimationState("resourcedisplay", "50")
      elseif resourceValue >= 0.3 and resourceValue < 0.4 then animator.setAnimationState("resourcedisplay", "40")
      elseif resourceValue >= 0.2 and resourceValue < 0.3 then animator.setAnimationState("resourcedisplay", "30")
      elseif resourceValue >= 0.1 and resourceValue < 0.2 then animator.setAnimationState("resourcedisplay", "20")
      elseif resourceValue ~= 0.0 and resourceValue < 0.1 then animator.setAnimationState("resourcedisplay", "10")
      elseif resourceValue == 0.0 then animator.setAnimationState("resourcedisplay", "0")
      else animator.setAnimationState("resourcedisplay", "invisible")
    end
  end
  if self.displayTimer == 0.0 and resourceValue <= 0.35 and resourceValue ~= 0 then
	animator.setAnimationState("resourcedisplay", "0")
	self.displayTimer = 1
  end
end

function setHoverHeight(time, dt)
  --Sin makes you bob
  local sinTime = math.sin(time / self.bobInterval * 6.28)
  self.hoverHeight = self.maxHoverHeight + sinTime * self.bobAmount
end

function getCollisionEdges()
  local collisionPoly = mcontroller.collisionPoly()

  local edges = {
    left = 0,
    top = 0,
    right = 0,
    bottom = 0
  }

  for _,point in ipairs(collisionPoly) do
    if point[1] < edges.left then edges.left = point[1] end
    if point[2] > edges.top then edges.top = point[2] end
    if point[1] > edges.right then edges.right = point[1] end
    if point[2] < edges.bottom then edges.bottom = point[2] end
  end

  return edges
end

function update(dt)
  --Timers for abilities
  self.activeTimer = self.activeTimer + dt
  setHoverHeight(self.activeTimer, dt)
  self.boostDelay = math.max(0, self.boostDelay + dt) -- This function is from the old T4 Jetpack.
  self.displayTimer = math.max(self.displayTimer - dt, 0)
  self.soundTimer = math.max(self.soundTimer - dt, 0)
  visualEffects(dt)
  getResources()	
	
  --Ground distance calculation function
  mcontroller.controlParameters(self.movementParametersGround)
  groundDistance = findGroundDistance()
  position = mcontroller.position()
	
  --Movement parameters; uodate only when in gravity.
  if world.gravity(mcontroller.position()) > 0.1 then
    shutdownTimer(dt)
    waterHover()
    inWaterMovement()
    landHover()
  end
	
  --flySpace() -- keep this updating at all times.
end

function shutdownTimer(dt)
  --Shutdown timer conditions
  actualXVelocity = mcontroller.xVelocity()
  if not mcontroller.groundMovement()
  and actualXVelocity >= -1 and actualXVelocity <= 1 then
    self.shutdownTimer = math.max(0, self.shutdownTimer + dt)
	if self.shutdownTimer > 5 then
      mcontroller.setYVelocity(-10)
	end
  else
    self.shutdownTimer = 0
  end
end

function landHover()
  if groundDistance > 7 and groundDistance < 14 and not status.resourceLocked(resource)
  or groundDistance > 7 and groundDistance < 14 and not resourceValue ~= 0 then
    mcontroller.controlApproachYVelocity(14 - groundDistance, 250)
    --mcontroller.setYVelocity((mcontroller.yVelocity() - groundDistance) + self.hoverHeight)
    mcontroller.controlParameters(self.movementParametersHover)
    mcontroller.controlParameters({ gravityMultiplier = 0.0001 })
    mcontroller.controlApproachVelocity({0, 0}, 5)
    mcontroller.controlModifiers({ speedModifier = 2.5 })
    status.overConsumeResource(resource, 0.02)
	--loadSound()
  elseif groundDistance > 14 then
    mcontroller.controlParameters(self.movementParametersAirjump)
	mcontroller.controlParameters({ gravityMultiplier = 0.35 })
	mcontroller.controlModifiers({ speedModifier = 2.5 })
	status.overConsumeResource(resource, 0.02)
	--loadSound()
  end
end

function waterHover()
if world.liquidAt({mcontroller.xPosition(), mcontroller.yPosition() - 10})
  and groundDistance > 1
  and not status.resourceLocked(resource) then
    mcontroller.controlParameters({
	  airBuoyancy = 1,
	  gravityMultiplier = 0.0001
    })
	mcontroller.controlApproachYVelocity(1, 5000)
  end
end

function inWaterMovement()
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  or status.resourceLocked(resource)
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement() then
	--animator.setParticleEmitterActive("exhaustright", false) -- we're out of fuel. Switch the engines off
    --animator.setParticleEmitterActive("exhaustleft", false)
	if not self.landingCheck then
	  status.setResource(resource, 0)
	  mcontroller.controlModifiers({ jumpingSuppressed = true })
      mcontroller.controlParameters({ gravityMultiplier = 0.75 })
	end
  elseif resourceValue == 0 and mcontroller.liquidMovement()
	  or resourceValue == 0 and mcontroller.groundMovement()
	  or status.resourceLocked(resource) and mcontroller.liquidMovement()
	  or status.resourceLocked(resource) and mcontroller.groundMovement() then
	mcontroller.controlModifiers({ jumpingSuppressed = true, movementSuppressed = false, speedModifier = 0.5 })
	mcontroller.controlModifiers({ jumpingSuppressed = false })
	self.landingCheck = true
	animator.stopAllSounds("fly")
  elseif resourceValue ~= 0 or not status.resourceLocked(resource) then
    self.landingCheck = false
  end
end

function slowFall()
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and self.fallSpeedLimit > mcontroller.yVelocity()
  or status.resourceLocked(resource)
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and self.fallSpeedLimit > mcontroller.yVelocity() then
    mcontroller.controlApproachYVelocity(-35, 350)
  end
end

function flySpace()
  
  if mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
	status.overConsumeResource(resource, 0.005)
    if not self.isBoosting and self.boostDelay > 0.01 then
	  self.isBoosting = true
	elseif self.isBoosting and self.boostDelay > 0.02 then
	  self.isBoosting = false
	  self.boostDelay = 0
	end
	
    if mcontroller.yVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() + 0.4})
	elseif mcontroller.yVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.yVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() - 0.4})
	elseif mcontroller.yVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
    if mcontroller.xVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() + 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.xVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() - 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	--reference code
	--if mcontroller.xVelocity() > 0.05 and self.isBoosting then
    --  mcontroller.setVelocity({mcontroller.xVelocity() + 10, mcontroller.yVelocity()})
	--end
	
  elseif not mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
    mcontroller.setVelocity({0,0})
  end
end

function getClosestBlockYDistance(lineStart, lineEnd, ignorePlatforms)
  local yDistance = false
  local collisionSet = {"Null", "Block", "Dynamic", "Platform"}
  if ignorePlatforms then
    collisionSet = {"Null", "Block", "Dynamic", "Slippery"}
  end
  local blocks = world.collisionBlocksAlongLine(lineStart, lineEnd, collisionSet)
  if #blocks > 0 then
    yDistance = lineStart[2] - (blocks[1][2] + 1)
  end

  -- sb.logInfo("Block: %s Distance: %s", blocks[1], yDistance)

  return yDistance
end

function findGroundDistance()
  local position = mcontroller.position()
  --These are so rays don't start inside blocks
  local sideEdgeOffset = 0.1
  local bottomStartOffset = 0.5
  local centerBottomStartOffset = 0.1

  --Left ray
  local lineStart = {
    position[1] + self.edges.left + sideEdgeOffset,
    position[2] + self.edges.bottom + bottomStartOffset
  }
  local lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - bottomStartOffset
  }

  local leftGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  leftGroundDistance = leftGroundDistance - bottomStartOffset

  --Right ray
  lineStart = {
    position[1] + self.edges.right - sideEdgeOffset,
    position[2] + self.edges.bottom + bottomStartOffset
  }
  local lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - bottomStartOffset
  }

  local rightGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  rightGroundDistance = rightGroundDistance - bottomStartOffset

  --Center ray
  lineStart = {
    position[1],
    position[2] + self.edges.bottom + centerBottomStartOffset
  }
  lineEnd = {
    lineStart[1],
    lineStart[2] - self.hoverHeight * 2 - centerBottomStartOffset
  }

  local centerGroundDistance = getClosestBlockYDistance(lineStart, lineEnd, false) or 9999 --Really big number
  centerGroundDistance = centerGroundDistance - centerBottomStartOffset

  --Get the closest one
  local groundDistance = math.min(leftGroundDistance, rightGroundDistance)
  groundDistance = math.min(groundDistance, centerGroundDistance)

  return groundDistance
end

function uninit()
  effect.expire()
end
