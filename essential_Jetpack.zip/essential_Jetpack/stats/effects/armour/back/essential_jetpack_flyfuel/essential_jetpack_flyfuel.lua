require "/scripts/util.lua"

function init()
  self.isBoosting = false
  self.boostDelay = 0
  self.movementParameters = config.getParameter("movementParameters", {})
  self.movementParametersOutOfFuelGround = config.getParameter("movementParametersOutOfFuelGround", {})
  self.movementParametersOutOfFuelFalling = config.getParameter("movementParametersOutOfFuelFalling", {})
  self.landingCheck = false
  self.fallSpeedLimit = -40
  animator.setAnimationState("resourcedisplay", "invisible")
  self.displayTimer = 0
  getResources()
  self.soundTimer = 0
end

function getResources()
  resource = "essential_jetpack_fuel"
  resourceValue = status.resourcePercentage(resource)
end

function loadSound()
  if self.soundTimer == 0 then
    playSound()
  end
end

function playSound()
  if self.soundTimer == 0 then
	animator.playSound("fly", 0)
    self.soundTimer = 2
  end
end

function update(dt)
  --Utilities
  self.boostDelay = math.max(0, self.boostDelay + dt)
  self.displayTimer = math.max(self.displayTimer - dt, 0)
  self.soundTimer = math.max(self.soundTimer - dt, 0)
  visualEffects(dt)
  getResources()
	
  --Movement parameters; uodate only when in gravity.
  if world.gravity(mcontroller.position()) > 0.1 then
    resourceLockedMovement()
    flyAtmosphere()
	slowFall()
  end
	
  --flySpace() -- keep this updating at all times.
end

function visualEffects(dt)
  local playerLounging = world.loungeableQuery(entity.position(), 10)
  if not mcontroller.groundMovement()
	and not mcontroller.liquidMovement()
	and mcontroller.canJump()
    or mcontroller.falling()
	and not mcontroller.groundMovement() 
	and not mcontroller.liquidMovement() then
	if mcontroller.facingDirection() == 1 then 
	  animator.setParticleEmitterActive("exhaustright", true)
	  animator.setParticleEmitterActive("exhaustleft", false)
	  loadSound()
    elseif mcontroller.facingDirection() == -1 then
	  animator.setParticleEmitterActive("exhaustright", false)
	  animator.setParticleEmitterActive("exhaustleft", true)
	  loadSound()
	end
  elseif mcontroller.groundMovement() or mcontroller.isColliding() or playerLounging then
	animator.resetTransformationGroup("exhaust")
	animator.stopAllSounds("fly")
	animator.setParticleEmitterActive("exhaustright", false)
    animator.setParticleEmitterActive("exhaustleft", false)
  end
	
  if self.displayTimer < 0.5 then
    if resourceValue == 1.0 then animator.setAnimationState("resourcedisplay", "idle")
      elseif resourceValue >= 0.9 and resourceValue ~= 1.0 then animator.setAnimationState("resourcedisplay", "100")
      elseif resourceValue >= 0.8 and resourceValue < 0.9 then animator.setAnimationState("resourcedisplay", "90")
      elseif resourceValue >= 0.7 and resourceValue < 0.8 then animator.setAnimationState("resourcedisplay", "80")
      elseif resourceValue >= 0.6 and resourceValue < 0.7 then animator.setAnimationState("resourcedisplay", "70")
      elseif resourceValue >= 0.5 and resourceValue < 0.6 then animator.setAnimationState("resourcedisplay", "60")
      elseif resourceValue >= 0.4 and resourceValue < 0.5 then animator.setAnimationState("resourcedisplay", "50")
      elseif resourceValue >= 0.3 and resourceValue < 0.4 then animator.setAnimationState("resourcedisplay", "40")
      elseif resourceValue >= 0.2 and resourceValue < 0.3 then animator.setAnimationState("resourcedisplay", "30")
      elseif resourceValue >= 0.1 and resourceValue < 0.2 then animator.setAnimationState("resourcedisplay", "20")
      elseif resourceValue ~= 0.0 and resourceValue < 0.1 then animator.setAnimationState("resourcedisplay", "10")
      elseif resourceValue == 0.0 then animator.setAnimationState("resourcedisplay", "0")
      else animator.setAnimationState("resourcedisplay", "invisible")
    end
  end
  if self.displayTimer == 0.0 and resourceValue <= 0.35 and resourceValue ~= 0 then
	animator.setAnimationState("resourcedisplay", "0")
	self.displayTimer = 1
  end
end

function resourceLockedMovement()
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  or status.resourceLocked(resource)
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement() then
	animator.setParticleEmitterActive("exhaustright", false) -- we're out of fuel. Switch the engines off
    animator.setParticleEmitterActive("exhaustleft", false)
    if not self.landingCheck then 
	  --status.setResource(resource, 0)
	  mcontroller.controlModifiers({ jumpingSuppressed = true })
	  mcontroller.controlParameters(self.movementParametersOutOfFuelFalling)
	end
  elseif resourceValue == 0 and mcontroller.liquidMovement()
	  or resourceValue == 0 and mcontroller.groundMovement()
	  or status.resourceLocked(resource) and mcontroller.liquidMovement()
	  or status.resourceLocked(resource) and mcontroller.groundMovement() then
	mcontroller.controlParameters(self.movementParametersOutOfFuelGround)
	mcontroller.controlModifiers({ jumpingSuppressed = false })
	self.landingCheck = true
	animator.stopAllSounds("fly")
	animator.setParticleEmitterActive("exhaustright", false) -- we're out of fuel. Switch the engines off
    animator.setParticleEmitterActive("exhaustleft", false)
  elseif resourceValue ~= 0 or not status.resourceLocked(resource) then
    self.landingCheck = false
	mcontroller.controlParameters(self.movementParameters)
  end
end

function flyAtmosphere()
  if mcontroller.jumping() and resourceValue ~= 0 then
     status.overConsumeResource(resource, 0.075)
     mcontroller.controlParameters({ gravityMultiplier = 0.175 })
	 mcontroller.controlModifiers({ speedModifier = 2.5 })
  elseif mcontroller.jumping() or mcontroller.falling() then
     if resourceValue ~= 0 then
	   status.overConsumeResource(resource, 0.01)
	   mcontroller.controlParameters({ gravityMultiplier = 0.175 })
	   mcontroller.controlModifiers({ speedModifier = 2.5 })
	 end
  end
end

function slowFall()
  if resourceValue == 0
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and not self.landingCheck
  and self.fallSpeedLimit > mcontroller.yVelocity()
  or status.resourceLocked(resource)	
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement()
  and not self.landingCheck
  and self.fallSpeedLimit > mcontroller.yVelocity() then
    mcontroller.controlApproachYVelocity(self.fallSpeedLimit, 350)
  end
end

function flySpace()
  
  if mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
	status.overConsumeResource(resource, 0.005)
    if not self.isBoosting and self.boostDelay > 0.01 then
	  self.isBoosting = true
	elseif self.isBoosting and self.boostDelay > 0.02 then
	  self.isBoosting = false
	  self.boostDelay = 0
	end
	
    if mcontroller.yVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() + 0.4})
	elseif mcontroller.yVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.yVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition(), mcontroller.yPosition() - 0.4})
	elseif mcontroller.yVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
    if mcontroller.xVelocity() > 0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() + 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() > 0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	if mcontroller.xVelocity() < -0.0001 and self.isBoosting then
      mcontroller.setPosition({mcontroller.xPosition() - 0.4, mcontroller.yPosition()})
	elseif mcontroller.xVelocity() < -0.0001 and not self.isBoosting then
	  mcontroller.setVelocity({0,0})
	end
	
	--reference code
	--if mcontroller.xVelocity() > 0.05 and self.isBoosting then
    --  mcontroller.setVelocity({mcontroller.xVelocity() + 10, mcontroller.yVelocity()})
	--end
	
  elseif not mcontroller.flying() and world.gravity(mcontroller.position()) < 0.1 then
    mcontroller.setVelocity({0,0})
  end
end

function uninit()
  effect.expire()
end

