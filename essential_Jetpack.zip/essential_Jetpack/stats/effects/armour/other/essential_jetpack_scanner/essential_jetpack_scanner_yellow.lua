function init()
  effect.setParentDirectives("fade="..config.getParameter("neutral").."=0.3")
  script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
