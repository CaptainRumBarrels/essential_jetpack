function init()
  effect.setParentDirectives("fade="..config.getParameter("angry").."=0.6")
  script.setUpdateDelta(0)
end


function update(dt)

end

function uninit()
  
end
