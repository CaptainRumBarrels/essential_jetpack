require "/scripts/util.lua"

function init()
  self.searchDistance = config.getParameter("searchRadius")
  
  script.setUpdateDelta(1)
end

function update(dt)
  local targets = world.entityQuery(entity.position(), self.searchDistance, {
      withoutEntityId = entity.id(),
      includedTypes = { "creature", "monster", "npc" },
      order = "nearest"
    })
	
  for _, target in ipairs(targets) do
    if entity.entityInSight(target) then
	  if world.entityExists(target) then
	    if world.entityAggressive(target) and world.entityCanDamage(entity.id(), target) then
	  	  world.spawnProjectile("essential_jetpack_scanner_red", world.entityPosition(target), entity.id(), {0,0}, false, nil)
	    elseif not world.entityAggressive(target) and world.entityCanDamage(entity.id(), target) then
		  world.spawnProjectile("essential_jetpack_scanner_yellow", world.entityPosition(target), entity.id(), {0,0}, false, nil)
	    else
		  world.spawnProjectile("essential_jetpack_scanner_green", world.entityPosition(target), entity.id(), {0,0}, false, nil)
		end
	  end
    end
  end
end

function uninit()
end
