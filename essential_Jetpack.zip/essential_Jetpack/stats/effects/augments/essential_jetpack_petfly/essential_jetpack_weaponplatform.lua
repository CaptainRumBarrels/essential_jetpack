require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.edges = getCollisionEdges()
  self.searchDistance = config.getParameter("searchRadius")
  activateVisualEffects()
  self.reloadTimer = 2
	
  --Give pet minor health boost
  self.healthModifier = config.getParameter("healthModifier", 0)
  effect.addStatModifierGroup({{stat = "maxHealth", effectiveMultiplier = self.healthModifier}})
end

function update(dt)
  self.reloadTimer = math.max(self.reloadTimer - dt, 0)
  mcontroller.controlModifiers({ speedModifier = 2.5 })
  activateVisualEffects()
	
  local targets = world.entityQuery(entity.position(), self.searchDistance, {
      withoutEntityId = entity.id(),
      includedTypes = { "creature", "monster", "npc" },
      order = "nearest"
    })
	
  for _, target in ipairs(targets) do
    if entity.entityInSight(target) then
	  if world.entityExists(target) then
	    if world.entityAggressive(target) and world.entityCanDamage(entity.id(), target) then
		  loadWeapon()
		end
	  end
    end
  end
end

function loadWeapon()
  if self.reloadTimer == 0 then
    fireWeapon()
  end
end

function fireWeapon()
  local edges = getCollisionEdges()
  local boundBox = mcontroller.boundBox()

  --Particles at feet
  boundBox[2] = edges.bottom
  boundBox[4] = edges.bottom
	
  local projectileParameters = {
    power = 4,
    powerMultiplier = 1
  }
	
  if self.reloadTimer == 0 then
	world.spawnProjectile("essential_jetpack_weaponplatform_fire", vec2.add(entity.position(), {-0.6, boundBox[4] - 0.5}), entity.id(), {0,0}, false, projectileParameters)
	world.spawnProjectile("essential_jetpack_weaponplatform_fire", vec2.add(entity.position(), {0.6, boundBox[4] - 0.5}), entity.id(), {0,0}, false, projectileParameters)
    self.reloadTimer = 2
  end
end

function activateVisualEffects()
  local edges = getCollisionEdges()
  local boundBox = mcontroller.boundBox()

  --Particles at feet
  boundBox[2] = edges.bottom
  boundBox[4] = edges.bottom
  
  world.spawnProjectile("essential_jetpack_platformcollider", vec2.add(entity.position(), {0, boundBox[4] - 0.5}))
  world.spawnProjectile("essential_jetpack_weaponplatform", vec2.add(entity.position(), {0, boundBox[4] - 0.7}))
end

function getCollisionEdges()
  local collisionPoly = mcontroller.collisionPoly()

  local edges = {
    left = 0,
    top = 0,
    right = 0,
    bottom = 0
  }

  for _,point in ipairs(collisionPoly) do
    if point[1] < edges.left then edges.left = point[1] end
    if point[2] > edges.top then edges.top = point[2] end
    if point[1] > edges.right then edges.right = point[1] end
    if point[2] < edges.bottom then edges.bottom = point[2] end
  end

  return edges
end

function uninit()
  effect.expire()
end