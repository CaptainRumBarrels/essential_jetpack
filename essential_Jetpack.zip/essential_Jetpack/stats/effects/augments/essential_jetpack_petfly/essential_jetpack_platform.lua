require "/scripts/vec2.lua"
require "/scripts/util.lua"

function init()
  self.edges = getCollisionEdges()
  activateVisualEffects()
	
  -- Make pets more resilient
  self.healthModifier = config.getParameter("healthModifier", 0)
  effect.addStatModifierGroup({{stat = "maxHealth", effectiveMultiplier = self.healthModifier}})
end

function update(dt)
  mcontroller.controlModifiers({ speedModifier = 3.0 })
  activateVisualEffects()
end

function activateVisualEffects()
  local edges = getCollisionEdges()
  local boundBox = mcontroller.boundBox()

  --Particles at feet
  boundBox[2] = edges.bottom
  boundBox[4] = edges.bottom
  
  world.spawnProjectile("essential_jetpack_platformcollider", vec2.add(entity.position(), {0, boundBox[4] - 0.5}))
  world.spawnProjectile("essential_jetpack_platform", vec2.add(entity.position(), {0, boundBox[4] - 0.7}))
end

function getCollisionEdges()
  local collisionPoly = mcontroller.collisionPoly()

  local edges = {
    left = 0,
    top = 0,
    right = 0,
    bottom = 0
  }

  for _,point in ipairs(collisionPoly) do
    if point[1] < edges.left then edges.left = point[1] end
    if point[2] > edges.top then edges.top = point[2] end
    if point[1] > edges.right then edges.right = point[1] end
    if point[2] < edges.bottom then edges.bottom = point[2] end
  end

  return edges
end

function uninit()
  effect.expire()
end