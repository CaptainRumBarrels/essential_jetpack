require "/scripts/util.lua"

function init()
end

function update(dt)  
  --When not submerged in liquid
  if not mcontroller.liquidMovement() then
    if not self.statImmunityApplied then
      self.statModifier = effect.addStatModifierGroup({
          {stat = "poisonStatusImmunity", amount = 1},
          {stat = "tarImmunity", amount = 1},
          {stat = "tarStatusImmunity", amount = 1},
          {stat = "iceStatusImmunity", amount = 1},
		  {stat = "electricStatusImmunity", amount = 1},
          {stat = "waterImmunity", amount = 1},
          {stat = "wetImmunity", amount = 1},
          {stat = "slimeImmunity", amount = 1}
      })
      self.statImmunityApplied = true
    end
  --If out of liquid and effect is still active, remove it
  elseif self.statImmunityApplied then
    effect.removeStatModifierGroup(self.statModifier)
    self.statImmunityApplied = false
  end
	
  status.removeEphemeralEffect("sandstorm")
end

function uninit()
end