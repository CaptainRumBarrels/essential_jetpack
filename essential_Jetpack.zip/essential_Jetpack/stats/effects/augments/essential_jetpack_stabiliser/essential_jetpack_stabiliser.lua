require "/scripts/util.lua"
require "/scripts/vec2.lua"
require "/scripts/interp.lua"

function init()
  self.speedLimit = config.getParameter("speedLimit")
  self.movementParams = mcontroller.baseParameters()
  self.fallSpeedLimit = -25
end


function update(dt)
  mcontroller.controlParameters({
     speedLimit = self.speedLimit
  })
	
  if not mcontroller.groundMovement() or mcontroller.liquidMovement() then
    mcontroller.controlModifiers({
	  speedModifier = 1.5
	})
  end
	
  actualXVelocity = mcontroller.xVelocity()
  actualYVelocity = mcontroller.yVelocity()

  if not status.resourceLocked("energy")
  and actualXVelocity >= -5
  and actualXVelocity <= 5
  and actualYVelocity >= -5
  and actualYVelocity <= 2
  and not mcontroller.groundMovement()
  and not mcontroller.liquidMovement() then
	
    mcontroller.controlApproachYVelocity(0, 100)
	mcontroller.controlParameters({
	  gravityMultiplier = 0.01,
	  airFriction = 1.0
	})
	mcontroller.controlModifiers({speedModifier = 0.4})
	status.overConsumeResource("energy", 0.025)
	
  elseif status.resourceLocked("energy") or status.resource("energy") == 0 then
	self.movementParams = mcontroller.baseParameters()
  end
	
  if not mcontroller.groundMovement() or mcontroller.liquidMovement() then
    if self.fallSpeedLimit >= actualYVelocity then
      mcontroller.setYVelocity(self.fallSpeedLimit)
    end
  end
	
end

function uninit()

end

