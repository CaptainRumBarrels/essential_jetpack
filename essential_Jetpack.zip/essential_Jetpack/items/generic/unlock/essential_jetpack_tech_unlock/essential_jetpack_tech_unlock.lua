function init()

end

function activate(fireMode, shiftHeld)
  activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
  item.consume(1)
end

function uninit()

end
