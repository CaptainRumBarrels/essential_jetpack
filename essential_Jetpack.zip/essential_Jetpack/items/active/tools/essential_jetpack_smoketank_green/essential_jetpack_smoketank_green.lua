require "/scripts/vec2.lua"
require "/items/active/weapons/weapon.lua"

function init()
  self.rateOfFire = 0.035
  self.defaultTimeToLive = 25
  self.projectileCount = 0
  self.decayFactor = 30 --arbitray value to determine projectile life based on other variables.
  self.projectileCheck = true
end

function update(dt, fireMode, shiftHeld)
	
  local a = -5.0
  local b = 5.0
  self.randomX = a + (math.random() * (b - a))
  self.randomY = a + (math.random() * (b - a))
  self.rateOfFire = math.max(self.rateOfFire - dt, 0)
	
  self.projectileCount = math.max(self.projectileCount - (dt * 5), 0)
	
  self.timeToLive = self.defaultTimeToLive --self.defaultTimeToLive / (self.projectileCount / self.decayFactor)
	
  xMotion = self.randomX
  yMotion = self.randomY
	
  projectileParameters = {
    power = 0,
    powerMultiplier = 0,
	speed = 0.1,
	timeToLive = self.timeToLive
  }
	
  if self.timeToLive <= 5 then
	self.timeToLive = 5
  else
    self.timeToLive = self.timeToLive
  end
	
  if activeItem.fireMode() == "primary" and activeItem.hand() == "primary"
  or activeItem.fireMode() == "primary" and activeItem.hand() == "alt" then
    --animator.setParticleEmitterActive("smokecloud", true)
	activeItem.emote("happy")
	if self.rateOfFire == 0 and self.projectileCheck then
	  world.spawnProjectile("essential_jetpack_smoketankcloud_green", entity.position(), entity.id(), {xMotion, yMotion}, false, projectileParameters)
	  self.rateOfFire = 0.035
	  self.projectileCount = self.projectileCount + 1
	end
  else
	--animator.setParticleEmitterActive("smokecloud", false)
  end
	
  if self.projectileCount >= 130 then
    self.projectileCheck = false
  elseif self.projectileCount == 0 then
	self.projectileCheck = true	
  end
	
  activeItem.setHoldingItem(false)
	
end

function uninit()

end