function init()
  
end

function activate(fireMode, shiftHeld)
  if status.resourcePercentage("essential_jetpack_manuallogic") == 0.0 then
    activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
	status.setResource("essential_jetpack_manuallogic", 1)
  end
  --activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
end

function uninit()
  
end
