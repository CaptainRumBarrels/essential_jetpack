function init()
  status.resetResource("essential_jetpack_manuallogic")
end

function activate(fireMode, shiftHeld)
  if status.resourcePercentage("essential_jetpack_manuallogic") == 0.0 then
    activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
	status.setResource("essential_jetpack_manuallogic", 1)
  end
  --activeItem.interact(config.getParameter("interactAction"), config.getParameter("interactData"));
end

function uninit()
  status.resetResource("essential_jetpack_manuallogic")
end
