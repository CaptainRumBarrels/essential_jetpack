require "/scripts/vec2.lua"
require "/items/active/weapons/weapon.lua"

function init()
  -- scale damage and calculate energy cost
  self.pType = config.getParameter("projectileType")
  self.pParams = config.getParameter("projectileParameters", {})
  self.pParams.power = config.getParameter("baseDps")
  self.energyPerShot = config.getParameter("energyUsage")

  self.fireOffsetDefault = config.getParameter("fireOffsetDefault")
  self.fireOffset2 = config.getParameter("fireOffset2")
  self.fireOffset3 = config.getParameter("fireOffset3")
  self.fireOffset4 = config.getParameter("fireOffset4")
  self.fireOffset5 = config.getParameter("fireOffset5")
  self.fireOffset6 = config.getParameter("fireOffset6")
  self.fireOffset7 = config.getParameter("fireOffset7")
  self.fireOffset8 = config.getParameter("fireOffset8")
	
  updateAim()

  storage.fireTimer = storage.fireTimer or 0
  self.recoilTimer = 0

  storage.activeProjectiles = storage.activeProjectiles or {}
  updateCursor()
end

function activate(fireMode, shiftHeld)
  if fireMode == "alt" then
    --triggerProjectiles()
		
  end
end

function update(dt, fireMode, shiftHeld)
  updateAim()

  storage.fireTimer = math.max(storage.fireTimer - dt, 0)
  self.recoilTimer = math.max(self.recoilTimer - dt, 0)

  if fireMode == "primary"
      and storage.fireTimer <= 0
      and not world.pointTileCollision(firePosition1())
      and status.overConsumeResource("energy", self.energyPerShot) then

    storage.fireTimer = config.getParameter("fireTime", 1.0)
    if world.gravity(mcontroller.position()) > 0.1 then
	  fire()
	elseif world.gravity(mcontroller.position()) < 0.1 then
	  fireBurst()
	end
 end

  activeItem.setRecoil(self.recoilTimer > 0)

  updateProjectiles()
  updateCursor()
end

function updateCursor()
  if #storage.activeProjectiles > 0 then
    --activeItem.setCursor("/cursors/chargeready.cursor")
  else
    activeItem.setCursor("/cursors/reticle0.cursor")
  end
end

function uninit()
  for i, projectile in ipairs(storage.activeProjectiles) do
    world.callScriptedEntity(projectile, "setTarget", nil)
  end
end

function fire()
  self.pParams.powerMultiplier = activeItem.ownerPowerMultiplier()
  local projectileId1 = world.spawnProjectile(
      self.pType,
      firePosition3(),
      activeItem.ownerEntityId(),
      aimVector(),
      false,
      self.pParams
    )
  local projectileId2 = world.spawnProjectile(
      self.pType,
      firePosition7(),
      activeItem.ownerEntityId(),
      aimVector(),
      false,
      self.pParams
    )
  
  if projectileId1 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId1
  end
  if projectileId2 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId2
  end
  animator.burstParticleEmitter("fireParticles")
  animator.playSound("fire")
  self.recoilTimer = config.getParameter("recoilTime", 0.12)
end

function fireBurst()
  self.pParams.powerMultiplier = activeItem.ownerPowerMultiplier()
  local projectileId1 = world.spawnProjectile(self.pType, firePosition1(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId2 = world.spawnProjectile(self.pType, firePosition2(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId3 = world.spawnProjectile(self.pType, firePosition3(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId4 = world.spawnProjectile(self.pType, firePosition4(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId5 = world.spawnProjectile(self.pType, firePosition5(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId6 = world.spawnProjectile(self.pType, firePosition6(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId7 = world.spawnProjectile(self.pType, firePosition7(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
  local projectileId8 = world.spawnProjectile(self.pType, firePosition8(), activeItem.ownerEntityId(), aimVectorBurst(), false, self.pParams)
		
  if projectileId1 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId1
  end
  if projectileId2 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId2
  end
  if projectileId3 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId3
  end
  if projectileId4 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId4
  end
  if projectileId5 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId5
  end
  if projectileId6 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId6
  end
  if projectileId7 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId7
  end
  if projectileId8 then
    storage.activeProjectiles[#storage.activeProjectiles + 1] = projectileId8
  end
  
  animator.burstParticleEmitter("fireParticles")
  animator.playSound("fire")
  self.recoilTimer = config.getParameter("recoilTime", 0.12)
end

function updateAim()
  self.aimAngle, self.aimDirection = activeItem.aimAngleAndDirection(self.fireOffsetDefault[2], activeItem.ownerAimPosition())
  activeItem.setArmAngle(0)
  activeItem.setFacingDirection(self.aimDirection)
end

function updateProjectiles()
  local newProjectiles = {}
  for i, projectile in ipairs(storage.activeProjectiles) do
    if world.entityExists(projectile) then
      newProjectiles[#newProjectiles + 1] = projectile
    end
  end
  storage.activeProjectiles = newProjectiles
end

function firePosition1()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffsetDefault))
end
function firePosition2()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset2))
end
function firePosition3()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset3))
end
function firePosition4()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset4))
end
function firePosition5()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset5))
end
function firePosition6()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset6))
end
function firePosition7()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset7))
end
function firePosition8()
  return vec2.add(mcontroller.position(), activeItem.handPosition(self.fireOffset8))
end

function aimVector()
  local aimVector = vec2.rotate({1, 0}, self.aimAngle + sb.nrand(config.getParameter("inaccuracy", 0), 0))
  aimVector[1] = aimVector[1] * self.aimDirection
  return aimVector
end

function aimVectorBurst()
  local aimVector = vec2.rotate({1, 0}, self.aimAngle + sb.nrand(config.getParameter("inaccuracyBurst", 0), 0))
  aimVector[1] = aimVector[1] * self.aimDirection
  return aimVector
end
