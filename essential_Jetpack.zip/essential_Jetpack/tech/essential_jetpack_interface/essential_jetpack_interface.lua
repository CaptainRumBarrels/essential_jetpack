require "/scripts/vec2.lua"
require "/scripts/keybinds.lua"

function init()
  
end

function uninit()
  status.setResource("essential_jetpack_interfacelogic", 0)
end

function update(args, dt)
  if not self.specialLast and args.moves["special1"] and status.resourcePercentage("essential_jetpack_interfacelogic") == 0 then
    world.sendEntityMessage(entity.id(),"interact","ScriptPane","/interface/scripted/essential_jetpack_checkfuel/essential_jetpack_checkfuel.config")
	status.setResource("essential_jetpack_interfacelogic", 1)
  end
end