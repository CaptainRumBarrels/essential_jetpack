require "/scripts/vec2.lua"
require "/scripts/keybinds.lua"

function init()
  self.groundCheck = true
  self.launchTimer = 0
  animator.setAnimationState("launching", "off")
  self.playSound = false
end

function uninit()
  
end

function update(args, dt)
  if not mcontroller.liquidMovement() then
	
  if args.moves["down"] and world.gravity(mcontroller.position()) > 0.1 then
	mcontroller.controlApproachYVelocity(-11, 250)
  end
	
  if mcontroller.groundMovement() or mcontroller.liquidMovement() or mcontroller.onGround() then
    mcontroller.controlModifiers({
      speedModifier = 1.20
    })
  else
	mcontroller.controlModifiers({
      speedModifier = 1.0
    })
  end
	
  if args.moves["up"] and world.gravity(mcontroller.position()) > 0.1 then
	self.launchTimer = math.max(0, self.launchTimer + args.dt)
	if self.launchTimer < 0.5 then
	  --mcontroller.setVelocity({0,0})
	  animator.setParticleEmitterActive("launchParticles", true)
	  animator.setAnimationState("launching", "on")
	elseif self.launchTimer >= 0.5 and self.launchTimer < 1.0 and self.groundCheck then
	  --mcontroller.controlApproachYVelocity(500, 650)
	  mcontroller.setYVelocity(40)
	  animator.setParticleEmitterActive("launchParticles", true)
	  animator.setAnimationState("launching", "on")
	  if not self.playSound then
	    animator.playSound("boost", 0)
		self.playSound = true
	  end
    elseif self.launchTimer >= 1.0 then
	  self.groundCheck = false
	  animator.setParticleEmitterActive("launchParticles", false)
	  animator.setAnimationState("launching", "off")
	  animator.resetTransformationGroup("essential_jetpack_playerlaunchtrail")
	end	
  else
    animator.setParticleEmitterActive("launchParticles", false)
	animator.setAnimationState("launching", "off")
	animator.resetTransformationGroup("essential_jetpack_playerlaunchtrail")
	self.playSound = false
  end
	
  --if mcontroller.groundMovement() or mcontroller.liquidMovement() or mcontroller.onGround() then
    if self.launchTimer >= 4.0 then
	  self.groundCheck = true
	  self.launchTimer = 0 
	  animator.setParticleEmitterActive("launchParticles", false)
	  animator.setAnimationState("launching", "off")
	  animator.resetTransformationGroup("essential_jetpack_playerlaunchtrail")
	  self.playSound = false
	end
  --end
	
  animator.setFlipped(mcontroller.facingDirection() == -1)
		
  end
end