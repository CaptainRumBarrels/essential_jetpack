function init()
  self.required = 100
  
  update()
end

function update(dt)
  resourceFuel()
  resourceEnergy()
  if status.resourcePercentage("essential_jetpack_interfacelogic") == 0 then
	pane.dismiss()	
  end
end

function resourceFuel()
  local resourceFuel = status.resourcePercentage("essential_jetpack_fuel") * 100
  local resourceValue = status.resource("essential_jetpack_fuel")
  widget.setText("resourceFuelLabelPercent", math.floor(string.format("%s", resourceFuel)))
  widget.setText("resourceFuelLabelValue", math.floor(string.format(resourceValue)))
  widget.setFontColor("resourceFuelLabel", resourceFuel >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceFuelBar", resourceFuel / 100)
end

function resourceEnergy()
  local resourceEnergy = status.resourcePercentage("energy") * 100
  local resourceEnergyValue = status.resource("energy")
  widget.setText("resourceEnergyLabelPercent", math.floor(string.format("%s", resourceEnergy)))
  widget.setText("resourceEnergyLabelValue", math.floor(string.format(resourceEnergyValue)))
  widget.setFontColor("resourceEnergyLabel", resourceEnergy >= self.required and {255, 255, 255} or {255, 255, 255})
  widget.setProgress("resourceEnergyBar", resourceEnergy / 100)
end

function uninit()
  status.setResource("essential_jetpack_interfacelogic", 0)
end

function techCurveEnable()
  player.equipTech("essential_jetpack_curve")
end

function techLoopEnable()
  player.equipTech("essential_jetpack_loop")
end

function techStallEnable()
  player.equipTech("essential_jetpack_stalldive")
end

function techLeafEnable()
  player.equipTech("essential_jetpack_fallingleaf")
end