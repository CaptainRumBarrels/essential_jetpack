function init()
  self.transferTimer = 0
  self.completeTimer = 1.5
  self.closeGuiDelay = 1
  self.loadingSoundActive = false
  self.loadTech = false
  self.enableTech = false
  self.loadingSound = config.getParameter("loadingSound")
end

function update(dt)
  self.transferTimer = math.max(0, self.transferTimer + dt)
  widget.setProgress("loadingBar", self.transferTimer / self.completeTimer)
  
  if not self.loadingSoundActive then
    pane.playSound(self.loadingSound)
	self.loadingSoundActive = true
	
  end
  
  if not self.loadTech then
    self.loadTech = true -- First enable the tech
	player.makeTechAvailable("essential_jetpack_loop")
	player.makeTechAvailable("essential_jetpack_curve")
	player.makeTechAvailable("essential_jetpack_stalldive")
	player.makeTechAvailable("essential_jetpack_fallingleaf")
	player.makeTechAvailable("essential_jetpack_legs")
	player.makeTechAvailable("essential_jetpack_interface")
	
	if not self.enableTech and self.loadTech then
	  self.enableTech = true -- Then AutoUnlock the tech
	  player.enableTech("essential_jetpack_loop")
	  player.enableTech("essential_jetpack_curve")
	  player.enableTech("essential_jetpack_stalldive")
	  player.enableTech("essential_jetpack_fallingleaf")
	  player.enableTech("essential_jetpack_legs")
	  player.enableTech("essential_jetpack_interface")
	end
  end
  
  if self.transferTimer > self.completeTimer + self.closeGuiDelay then
	pane.dismiss()
  end
end